from sqlalchemy import Column, Integer, String, Date
from app import db

class Usuario(db.Model):
    __tablename__ = 'usuarios'
    id = Column(Integer, primary_key=True)
    nome = Column(String(150), nullable=False)
    email = Column(String(150), unique=True, nullable=False)
    senha = Column(String(150), nullable=False)  # Criptografia recomendada
    data_nascimento = Column(Date, nullable=False)
