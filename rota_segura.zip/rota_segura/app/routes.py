from flask import Blueprint, render_template, request, redirect, url_for, flash
from app.models import db, Usuario

main = Blueprint('main', __name__)

@main.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('senha')

        # Simulação de autenticação
        usuario = Usuario.query.filter_by(email=email, senha=senha).first()
        if usuario:
            flash(f"Bem-vindo, {usuario.nome}!", "success")
            return redirect(url_for('main.home'))  # Redireciona para a Home
        else:
            flash("Credenciais inválidas. Tente novamente.", "error")
            return redirect(url_for('main.login'))

    return render_template('login.html')



@main.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        nome = request.form.get('nome')
        email = request.form.get('email')
        senha = request.form.get('senha')
        data_nascimento = request.form.get('data_nascimento')

        if not nome or not email or not senha or not data_nascimento:
            flash('Todos os campos são obrigatórios.', 'error')
            return redirect(url_for('main.cadastro'))

        # Criar o novo usuário
        novo_usuario = Usuario(
            nome=nome,
            email=email,
            senha=senha,  # Criptografia recomendada
            data_nascimento=data_nascimento
        )
        db.session.add(novo_usuario)
        db.session.commit()
        flash('Cadastro realizado com sucesso!', 'success')
        return redirect(url_for('main.login'))

    return render_template('cadastro.html', usuarios=Usuario.query.all())


@main.route('/home')
def home():
    return render_template('home.html')


@main.route('/consulta')
def consulta():
    usuarios = Usuario.query.all()  # Recupera todos os usuários do banco
    return render_template('consulta.html', usuarios=usuarios)

@main.route('/logout')
def logout():
    flash("Você saiu do sistema.", "info")
    return redirect(url_for('main.login'))